<?php
session_start();
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE HTML>
<html>
<head>
<title>TMS  | Use App Offers</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,700,600' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700,300' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
<link href="css/font-awesome.css" rel="stylesheet">
<!-- Custom Theme files -->
<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
</head>
<body>
<?php include('includes/header.php');?>
<!--- banner ---->
<div class="banner-3">
	<div class="container">
		<h1 class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;"> App Offers</h1>
	</div>
</div>
<!--- /banner ---->
<!---offer---->
<div class="container">
	<div class="holiday">

	<h3>UP TO 20% USD. OFF</h3>
        <br>
<h4>Offers Details:</h4>
        <br>
<ul>Wind up the year on a fabulous note with the Biggest Online Travel Sale!<br>

Book any Package & get flat 20% cashback (max cashback is USD 1000) in the form of ViaCash.</ul>  
<br>
<h4>How the offer works?</h4><br>
        <li>If you book Package for USD 5000, you will get a cashback of USD 500 Viacash.</li>
        <li>If you book Package for USD 4000, you will get a cashback of USD 450 Viacash.</li>
        <li>If you book Package for USD 7000, you will get a cashback of USD 540 Viacash.</li>
        <li>If you book Package for USD 9000, you will get a cashback of USD 600 Viacash.</li>


<div><a href="apps-offers.php" class="view">View More App Offers</a></div>
</div>
			<div class="clearfix"></div>
	</div>


<?php include('includes/footer.php');?>
<!-- signup -->
<?php include('includes/signup.php');?>
<!-- //signu -->
<!-- signin -->
<?php include('includes/signin.php');?>
<!-- //signin -->
<!-- write us -->
<?php include('includes/write-us.php');?>
<!-- //write us -->
</body>
</html>
