


<!--- routes ---->
<div class="routes">
	<div class="container">
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<i class="glyphicon glyphicon-list-alt"></i>
			</div>
			<div class="rou-rgt wow fadeInDown animated" data-wow-delay=".5s">
				<h3>50,000+</h3>
				<p>Enquiries</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left">
			<div class="rou-left">
				<i class="fa fa-user"></i>
			</div>
			<div class="rou-rgt">
				<h3>2,300+</h3>
				<p>Regestered users</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="col-md-4 routes-left wow fadeInRight animated" data-wow-delay=".5s">
			<div class="rou-left">
				<i class="fa fa-ticket"></i>
			</div>
			<div class="rou-rgt">
				<h3>9,00,00,000+</h3>
				<p>Booking</p>
			</div>
				<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right">
	<div class="container">

		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<ul>
				<li><a class="facebook" href="https://www.facebook.com/theprojectwallet/"><span>Facebook</span></a></li>
				<li><a class="twitter" href="https://twitter.com/"><span>Twitter</span></a></li>
				<li><a class="flickr" href="https://flickr.com/"><span>Flickr</span></a></li>
				<li><a class="googleplus" href="https://google.com/"><span>Google+</span></a></li>
				<li><a class="dribbble" href="https://dribbble.com/"><span>Dribbble</span></a></li>
			</ul>
		</div>
		<p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© 2017 TMS . Brought To You By <a href="http://www.theprojectwallet.com">The Project Wallet. </a></p>
	</div>
</div>
